import matplotlib.pyplot as plt
import seaborn as sns

def plot_returns(returns_df):
    sns.barplot(x="Ticker", y="Gain", data=returns_df)
    plt.title("Investment Gains")
    plt.ylabel("Gain in ₹")
    plt.show()
