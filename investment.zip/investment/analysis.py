import pandas as pd
from market_data import fetch_current_price

# def calculate_portfolio_value(df):
#     total_value = 0
#     for _, row in df.iterrows():
#         current_price = fetch_current_price(row["Ticker"])
#         total_value += row["Shares"] * current_price
#     return total_value

# def calculate_returns(df):
#     returns = []
#     for _, row in df.iterrows():
#         current_price = fetch_current_price(row["Ticker"])
#         gain = (current_price - row["Buy Price"]) * row["Shares"]
#         returns.append({"Ticker": row["Ticker"], "Gain": gain})
#     return pd.DataFrame(returns)
def calculate_portfolio_value(df):
    total_value = 0
    for _, row in df.iterrows():
        try:
            current_price = fetch_current_price(row["Ticker"])
            total_value += row["Shares"] * current_price
        except Exception as e:
            print(f"⚠️ Skipping {row['Ticker']}: {e}")
    return total_value

def calculate_returns(df):
    returns = []
    for _, row in df.iterrows():
        try:
            current_price = fetch_current_price(row["Ticker"])
            gain = (current_price - row["Buy Price"]) * row["Shares"]
            returns.append({"Ticker": row["Ticker"], "Gain": gain})
        except Exception as e:
            print(f"⚠️ Skipping {row['Ticker']}: {e}")
    return pd.DataFrame(returns)
