from portfolio import load_portfolio, add_investment
from analysis import calculate_portfolio_value, calculate_returns
from report import plot_returns

def main():
    print("📊 Investment Portfolio Manager")
    df = load_portfolio()
    print(df)

    choice = input("Add new investment? (y/n): ")
    if choice.lower() == "y":
        ticker = input("Ticker: ").upper()

        shares = int(input("Shares: "))
        buy_price = float(input("Buy Price: "))
        add_investment(ticker, shares, buy_price)

    df = load_portfolio()
    value = calculate_portfolio_value(df)
    print(f"💰 Total Portfolio Value: ₹{value:.2f}")

    returns_df = calculate_returns(df)
    print(returns_df)

    plot_returns(returns_df)

if __name__ == "__main__":
    main()
