# # market_data.py
# import yfinance as yf

# def fetch_current_price(ticker):
#     stock = yf.Ticker(ticker)
#     return stock.history(period="1d")["Close"].iloc[-1]

# def fetch_historical_data(ticker, period="6mo"):
#     stock = yf.Ticker(ticker)
#     return stock.history(period=period)

import yfinance as yf

# def fetch_current_price(ticker):
#     stock = yf.Ticker(ticker).upper
#     hist = stock.history(period="1d")
#     if hist.empty:
#         print(f"Warning: No data found for ticker '{ticker}'. It may be delisted or invalid.")
#         return None  # or a default value like 0.0
#     return hist["Close"].iloc[-1]

def fetch_current_price(ticker):
    stock = yf.Ticker(ticker)
    history = stock.history(period="1d")
    if history.empty or "Close" not in history:
        raise ValueError(f"No data available for ticker: {ticker}")
    return history["Close"].iloc[-1]
