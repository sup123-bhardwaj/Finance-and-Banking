import os
import pandas as pd

PORTFOLIO_FILE = "data/portfolio.csv"

def load_portfolio():
    try:
        return pd.read_csv(PORTFOLIO_FILE)
    except FileNotFoundError:
        return pd.DataFrame(columns=["Ticker", "Shares", "Buy Price"])

def save_portfolio(df):
    os.makedirs("data", exist_ok=True)  # Create 'data' folder if it doesn't exist
    df.to_csv(PORTFOLIO_FILE, index=False)

def add_investment(ticker, shares, buy_price):
    df = load_portfolio()
    df = pd.concat([df, pd.DataFrame([[ticker, shares, buy_price]], columns=df.columns)], ignore_index=True)
    #save_portfolio(df)
    df["Ticker"] = df["Ticker"].str.upper()
    df = df.groupby("Ticker", as_index=False).agg({"Shares": "sum", "Buy Price": "mean"})
    save_portfolio(df)



