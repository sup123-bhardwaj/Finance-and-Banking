import yfinance as yf

def fetch_current_price(ticker):
    stock = yf.Ticker(ticker)
    return stock.history(period="1d")["Close"].iloc[-1]

def fetch_historical_data(ticker, period="6mo"):
    stock = yf.Ticker(ticker)
    return stock.history(period=period)
